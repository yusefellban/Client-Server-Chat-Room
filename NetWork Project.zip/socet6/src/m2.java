public class m2 {
    public static void main(String[] args) {

        new  Client1("mohamed");
    }
}
