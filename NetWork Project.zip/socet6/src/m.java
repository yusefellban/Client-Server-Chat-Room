public class m {
    public static void main(String[] args) {

        new  Client1("ali");
    }
}
