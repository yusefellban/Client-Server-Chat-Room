import java.io.*;
import java.net.*;
import java.util.ArrayList;
import java.util.List;


public class Server {
    private static List<PrintWriter> clientWriters = new ArrayList<>();

    public static void main(String[] args) {
        try {
            ServerSocket serverSocket = new ServerSocket(32510);
            System.out.println("Server is running...");

            while (true) {
                // Accept new client connections
                Socket clientSocket = serverSocket.accept();
                System.out.println("New client connected.");

                // Create a new thread to handle the client
                Thread clientThread = new Thread(new ClientHandler(clientSocket));
                clientThread.start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Method to broadcast a message to all clients
    public static synchronized void broadcastMessage(String message) {
        for (PrintWriter writer : clientWriters) {
            writer.println(message);
        }
    }

    // Method to add a client writer to the list
    public static synchronized void addClientWriter(PrintWriter writer) {
        clientWriters.add(writer);
    }

    // Method to remove a client writer from the list
    public static synchronized void removeClientWriter(PrintWriter writer) {
        clientWriters.remove(writer);
    }
}
