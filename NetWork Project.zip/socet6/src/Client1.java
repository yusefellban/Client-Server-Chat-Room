import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

public class Client1  extends  JFrame{
    private JPanel content;
    private  JTextField messageField;
    private  JButton btn;
    private   JTextArea chatArea;
    String name;
    private  Socket clientSocket;
    private  BufferedReader inputStream;
    private static PrintWriter outputStream;
 public Client1(String name){
     this.name=name;
     this.setContentPane(content);
     this.setSize(300,500);
     this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
     this.setTitle("Clint");


     btn.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent e) {
             sendMessage();
         }
     });



     this.setVisible(true);

     try {
         // Connect to the server
         clientSocket = new Socket("127.0.0.1", 32510);
         System.out.println("Client1 has connected to the server!");

         // Initialize input and output streams
         inputStream = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
         outputStream = new PrintWriter(clientSocket.getOutputStream(), true);

         // Start a thread for receiving messages
         Thread receiveThread = new Thread(new Runnable() {
             synchronized public void run() {
                 try {
                     String receivedMessage;
                     while ((receivedMessage = inputStream.readLine()) != null) {
                         appendMessage(receivedMessage);
                     }
                 } catch (IOException e) {
                     e.printStackTrace();
                 }
             }
         });
         receiveThread.start();
     } catch (IOException e) {
         e.printStackTrace();
     }

    }






    // Method to send a message to the server
    private   void sendMessage() {
        String message = messageField.getText();
        if (!message.isEmpty()) {
            outputStream.println(name +"  :"+ message);
            messageField.setText("");
//            appendMessage("me: " + message);
        }
    }

    // Method to append a message to the chat area
    private   void appendMessage(String message) {
        chatArea.append(message + "\n");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new Client1("");
            }
        });
    }


}
