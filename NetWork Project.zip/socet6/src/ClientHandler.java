import java.io.*;
import java.net.*;

public class ClientHandler implements Runnable {
    private Socket clientSocket;
    private PrintWriter clientWriter;

    public ClientHandler(Socket clientSocket) {
        this.clientSocket = clientSocket;
    }

    @Override
       synchronized public void run() {
        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
            clientWriter = new PrintWriter(clientSocket.getOutputStream(), true);

            // Add client writer to the list
            Server.addClientWriter(clientWriter);

            String message;
            while ((message = reader.readLine()) != null) {
                System.out.println("Received from client: " + message);

                // Broadcast the message to all clients
                Server.broadcastMessage(message);
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            // Remove client writer from the list
            Server.removeClientWriter(clientWriter);
            try {
                clientSocket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
